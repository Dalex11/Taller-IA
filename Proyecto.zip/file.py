# Clase Nodo
class Nodo:
    #Constructor
    def __init__(self, estado, padre, operador):
        self.estado = estado
        self.padre = padre
        self.operador = operador
        self.costo = 0
        self.pos_valor_enemigo = (0,0,'0')
        self.semilla = 0

    def get_costo(self):
        return self.costo

    def set_costo(self,valor):
        self.costo = valor

def hallarPosicionNodoMenorCosto(colaN):
    arr = []
    for i in range(0, 4):
        nodo = min(colaN, key=lambda i: i.get_costo())
        posicion = colaN.index(nodo)
        arr.append(colaN.pop(posicion).get_costo())
    return arr

list = [
    Nodo(None,None,''),
    Nodo(None,None,''),
    Nodo(None,None,''),
    Nodo(None,None,'')
]

list[0].set_costo(8)
list[1].set_costo(1)
list[2].set_costo(3)
list[3].set_costo(5)

print(hallarPosicionNodoMenorCosto(list))

def hallarPosicionNodoMenorCosto(colaN):
    nodo = min(colaN, key=lambda x: x.get_costo())
    posicion = colaN.index(nodo)
    return posicion